#!/bin/bash
# ----------------------------------------------------
python -u ./Generate_HDF5_Dataset.py \
--destination_dir PATH_TO_DESTINITION_DIR \
--metadata_file_path PATH_TO_METADATA_FILE \
--source_dir PATH_TO_SOURCE_DIR \
--hdf5_file_name HDF_FILE_NAME
