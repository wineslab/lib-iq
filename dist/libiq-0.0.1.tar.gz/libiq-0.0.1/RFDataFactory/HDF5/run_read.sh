#!/bin/bash
# ----------------------------------------------------
python -u .//Read_HDF5_Dataset.py \
--hdf5_file_path PATH_TO_HDF5_FILE
