from keras.callbacks import ModelCheckpoint
import warnings

class CustomModelCheckpoint(ModelCheckpoint):
    def __init__(self, filepath,  **kwargs):
        """
        Additional keyword args are passed to ModelCheckpoint; see those docs for information on what args are accepted.
        :param filepath:
        :param alternate_model: Keras model to save instead of the default. This is used especially when training multi-
                                gpu models built with Keras multi_gpu_model(). In that case, you would pass the original
                                "template model" to be saved each checkpoint.
        :param kwargs:          Passed to ModelCheckpoint.
        """

        self.best_path = ''
        super(CustomModelCheckpoint, self).__init__(filepath, **kwargs)

    def __super_epoch_end(self, epoch, logs=None):
        logs = logs or {}
        self.epochs_since_last_save += 1
        self.saved = False
        if self.epochs_since_last_save >= self.period:
            self.epochs_since_last_save = 0
            filepath = self.filepath.format(epoch=epoch + 1, **logs)
            if self.save_best_only:
                current = logs.get(self.monitor)
                if current is None:
                    warnings.warn('Can save best model only with %s available, '
                                  'skipping.' % (self.monitor), RuntimeWarning)
                else:
                    if self.monitor_op(current, self.best):
                        if self.verbose > 0:
                            print('\nEpoch %05d: %s improved from %0.11f to %0.11f,'
                                  ' saving model to %s'
                                  % (epoch + 1, self.monitor, self.best,
                                     current, filepath))
                        self.best = current
                        if self.save_weights_only:
                            self.model.save_weights(filepath, overwrite=True)
                            self.saved = True
                        else:
                            self.model.save(filepath, overwrite=True)
                            self.saved = True
                    else:
                        if self.verbose > 0:
                            print('\nEpoch %05d: %s did not improve from %0.11f' %
                                  (epoch + 1, self.monitor, self.best))
            else:
                if self.verbose > 0:
                    print('\nEpoch %05d: saving model to %s' % (epoch + 1, filepath))
                if self.save_weights_only:
                    self.model.save_weights(filepath, overwrite=True)
                else:
                    self.model.save(filepath, overwrite=True)


    def on_epoch_end(self, epoch, logs=None):
        self.__super_epoch_end(epoch, logs)

        if self.saved:
            self.best_path = self.filepath.format(epoch=epoch + 1, **logs)
