All contributions following the `inbound=outbound` licensing model, as
described
[here](https://help.github.com/articles/github-terms-of-service/#6-contributions-under-repository-license),
and are copyright of their respective author(s).

When contributing code, please mimic the code style of the project.
Contributions should be made in the form of Pull Requests on [libsigmf's GitHub
project](https://github.com/deepsig/libsigmf).


